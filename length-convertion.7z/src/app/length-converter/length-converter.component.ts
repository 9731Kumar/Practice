import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'length-converter',
  templateUrl: './length-converter.component.html',
  styleUrls: ['./length-converter.component.css']
})
export class LengthConverterComponent implements OnInit {

  selectValue1: string = "Kilometre";
  selectValue2: string = "Kilometre";

  km1!:number;
  km2!: number;
  m2!: number;
  cm2!: number;

  lengthOptions = [
    {
      id: 0,
      label: 'Kilometre',
      unit: 'km'
    },
    {
      id: 1,
      label: 'Metre',
      unit: 'm'
    },
    {
      id: 2,
      label: 'Centimetre',
      unit: 'cm'
    }
  ];

  ngOnInit() {

  }

  convert1(data: any) {
    let value = data;
    this.km2 = value;
    this.km1=value;

    if (this.selectValue1 === 'Kilometre' || this.selectValue2 === 'Kilometre') {
      this.convert2(value)
    }

    // if(this.selectValue2 === 'Metre'){
    //   this.km2=value*1000;
    // } else if(this.selectValue2 === 'Centimetre'){
    //   this.km2=value*1000*100;
    // }

    // if(this.selectValue1 == 'Kilometre'){
    //   let m=value*1000;
    //   this.m2=m;

    //   let cm=m*100;
    //   this.cm2=cm;
    //   console.log("Metre:"+m);
    //   console.log("Centi"+cm); 
    // } else if( this.selectValue1 == 'Metre' ){
    //   let km=value/1000;
    //   this.km2=km;

    //   let cm=value*100;
    //   this.cm2=cm;
    //   console.log("kilo"+km);
    //   console.log("CM"+cm);

    // } else if( this.selectValue1 == 'Centimetre' ){
    //   let m=value/100;
    //   this.m2=m;

    //   let km=m/1000;
    //   this.km2=km;
    //   console.log("Metre"+m);
    //   console.log("Kilo"+km);
    // }
  }

  convert2(value: number) {

    if (this.selectValue1 === 'Kilometre') {
      if (this.selectValue2 === 'Metre') {
        this.km2 = value * 1000;
      } else if (this.selectValue2 === 'Centimetre') {
        this.km2=0;
        this.km2 = value * 1000 * 100;
      }
    }  else {
      if (this.selectValue1 === 'Metre') {
        this.km1 = value * 1000;
      } else if (this.selectValue1 === 'Centimetre') {
        this.km1=0;
        this.km1 = value * 1000 * 100;
      }
    }

  }

  convert3() {

  }

  convert4() {

  }

}
